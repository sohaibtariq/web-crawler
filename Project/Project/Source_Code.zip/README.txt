This zip file contains two folders, Project and Proj_2.

Project contains the source code that can be compiled on the terminal using the following command:
g++ -std=c++11 Project.cpp -0 proj -lsfml-network -lsfml-system


Proj_2 contains files that contain the application with GUI.
The GUI was made in Qt5 and is required to run the application(as far as I know)
I have contained an executable of the program as well, but I am not sure whether it will run on other machines without Qt.
